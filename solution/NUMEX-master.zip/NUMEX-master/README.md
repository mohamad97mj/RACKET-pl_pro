# NUMEX
<p align="center">
    <img src="http://uupload.ir/files/6nag_logo.png">
</p>

---
The pure functional programming language interpreter, built with Racket under supervision of Prof. Mehran S. Fallah.
This project has to do with **NUMEX** (Number-Expression Programming Language). NUMEX programs are written directly in Racket by using the constructors defined by the structs defined at the beginning of _project.rkt_. You can simply download the whole project specification from the reports folder.
